n=int(input("Enter the year upto which leap years are to be displayed:")) 
print("Future leap years") 
for i in range(2024,n,4):
    print(i)